---
cadence: "60 - Ponctuelle"
last_run:
related_projects:
related_activities:
contexts:
areas:
description: "Toutes les étapes d'une sortie d'une journée, de l'idée au retour"
manual_order:
tags:
  - "type/processus"
---
# Organiser une sortie pédagogique

## Raison d'être
Une sortie d'une journée sans oubli: budget, parents, car, encodage, règles de la fédération.

## Prérequis
- La classe, la date, le lieu, le prix par élève
- Le plafond des frais de l'année (circulaire 9847, §9)

## Étapes
- [ ] Vérifier la date dans le [[Calendrier scolaire 2026-2027]] (pas de sortie pendant le CEB pour les 6e)
- [ ] Demander le devis du car (Fictibus) et réserver le lieu
- [ ] Calculer le prix par élève (entrée + car) et le comparer au plafond des frais
- [ ] Écrire le mot aux parents au moins une semaine avant, avec le coût ([[Écrire aux parents (Processus)]], circulaire 9847 §8.4)
- [ ] Inscrire la sortie dans le registre des activités
- [ ] Trouver les accompagnants: 1 adulte pour 8 élèves
- [ ] Demander à [[Martine Collard]] d'encoder la sortie et les paiements sur [[IT School]]
- [ ] La veille: liste des élèves qui n'ont pas payé, autorisations d'image
- [ ] Au retour: payer la facture du car, ajouter une ligne au bilan des sorties

## Outils et plateformes
- [[IT School]]
- Le dossier Activités de P1 à P6 ([[Dossier pro OneDrive]])

## Notes
- Une déclaration n'est obligatoire que pour une classe de dépaysement (1 mois avant, 6 semaines à l'étranger)

## Voir aussi
-
