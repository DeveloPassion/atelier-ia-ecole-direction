---
title: "Trouver une solution pour le plafond des frais des classes de neige P5"
status: "50 - Cette semaine"
necessity:
urgency:
impact:
effort:
priority: "20 - Très haute"
progress: 0
milestones:
date_created: "2026-11-09T07:45:00.000+01:00"
date_modified: "2026-11-09T07:45:00.000+01:00"
date_due: "2026-11-30"
date_scheduled:
date_completed:
recurrence:
time_estimate:
details:
time_entries:
time_spent: 0
total_time_spent:
date_last_session:
related_goals:
related_plans:
related_projects:
  - "[[Classes de neige P5 de mars 2027 (Projet)]]"
related_activities:
related_tasks:
related_ideas:
blocked_by:
contexts:
areas:
description:
manual_order:
tags:
  - "type/tache"
---
# Trouver une solution pour le plafond des frais des classes de neige P5

## Action
Préparer deux options pour ramener la part des parents sous 485 euros

## Contexte
Avant la réunion des parents du 3 décembre. Projet: [[Classes de neige P5 de mars 2027 (Projet)]]

## Notes
- 

## Références
- 

## Voir aussi
-
